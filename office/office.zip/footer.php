<script src="js/lib/jquery/jquery-3.2.1.min.js"></script>
	<script src="js/lib/popper/popper.min.js"></script>
	<script src="js/lib/tether/tether.min.js"></script>
	<script src="js/lib/bootstrap/bootstrap.min.js"></script>
	<script src="js/plugins.js"></script>

	<!-- <script src="js/lib/peity/jquery.peity.min.js"></script>
	<script src="js/lib/table-edit/jquery.tabledit.min.js"></script> -->
	

    <script src="js/app.js"></script>
</body>