<?php 
         $host="localhost";  
		 $admin="rabbanico_dev";
		 $password="?MK9v3YhNJaD@kw";
		 $database="rabbanico_order";
													  //==================
		 $link=mysqli_connect($host,$admin,$password,$database)or die("Belum Terkoneksi");

?>